# Practica 8

Realizar un programa que permita calcular la función que el usuario desee, según un menú de opciones:

* Kms a Mts/seg
* Kms a Millas
* Mts/Seg a Kms/h
* Millas a Kms

utilizando las fórmulas de conversión de velocidad, según sea el caso, y usando `ELSE IF` anidado ó `SWITCH()`.